const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const path = require('path');
const connectDb = require('./config/db');
const auth = require('./routes/auth');

const app = express();

dotenv.config({path:'./config/config.env'});

connectDb();

app.use(express.json());

app.use(cors());

app.use(express.urlencoded({extended: false}));

app.use(express.static(path.join(__dirname, 'static')));

app.use('/api/auth', auth);

/*app.get("*", (req, res) => {
  res.sendFile(path.resolve(__dirname, "../client", "build", "index.html"));
}); */

const PORT = process.env.PORT || 5001;
const server = app.listen(PORT, () => console.log(`Server running in "${process.env.NODE_ENV}" mode on port "${PORT}"`));

process.on('unhandledRejection', (err, promise) => {
  console.log('Error: ', err.message);
  server.close(() => process.exit(1));
})