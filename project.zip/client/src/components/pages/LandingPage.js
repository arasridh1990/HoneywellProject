import React from 'react'

const LandingPage = () => {
  return (
    <>
    <div style={{textAlign: "center"}}>
       <span style={{ fontSize: '2rem' }}>Hello world</span>
    </div>
    </>
  )
}

export default LandingPage